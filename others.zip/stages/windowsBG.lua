function onCreate()

	makeLuaSprite('bg', 'background', -300, -260);
	setScrollFactor('bg', 0.9, 0.9);

	addLuaSprite('bg', false);
end